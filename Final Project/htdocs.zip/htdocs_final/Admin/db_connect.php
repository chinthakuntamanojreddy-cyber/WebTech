<?php
// ============================================================
// CENTRAL DATABASE CONFIGURATION - Vehicle Management DB
// Fill in your credentials below before deploying
// ============================================================

$servername = "";   // e.g. "sql210.infinityfree.com"
$username   = "";   // e.g. "if0_41698831"
$password   = "";   // Your database password
$dbname     = "";   // e.g. "if0_41698831_vechile_management"

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
