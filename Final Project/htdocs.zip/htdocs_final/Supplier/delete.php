<?php
require_once __DIR__ . '/db_connect.php';
// DB connection
}

// Get ID and delete
if (isset($_GET['id'])) {
    $id = intval($_GET['id']);
    $sql = "DELETE FROM materials WHERE id = $id";

    if ($conn->query($sql) === TRUE) {
        echo "<script>alert('Record deleted successfully'); window.location.href='display.php';</script>";
    } else {
        echo "Error deleting record: " . $conn->error;
    }
} else {
    echo "Invalid ID.";
}

$conn->close();
?>
