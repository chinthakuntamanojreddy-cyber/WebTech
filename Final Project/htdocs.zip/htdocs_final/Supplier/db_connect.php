<?php
// ============================================================
// CENTRAL DATABASE CONFIGURATION - Supplier DB
// Fill in your credentials below before deploying
// ============================================================

$host     = "";   // e.g. "sql207.infinityfree.com"
$user     = "";   // e.g. "if0_38837486"
$password = "";   // Your database password
$database = "";   // e.g. "if0_38837486_supplier"

// Create connection
$conn = new mysqli($host, $user, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>
