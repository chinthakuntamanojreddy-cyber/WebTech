<?php
require_once __DIR__ . '/../Admin/db_connect.php';
// Enable error reporting
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Database connection
// Check connection
if ($_SERVER["REQUEST_METHOD"] == "POST") {

    // Retrieve form data
    $date = $_POST['date'];
    $vehicleNumber = $_POST['vehicleNumber'];
    $busRoute = $_POST['busRoute'];
    $timeIn = $_POST['timeIn'];
    $numEmployees = $_POST['numEmployees'];
    $reason = isset($_POST['reason']) ? $_POST['reason'] : null;

    // Insert data into Auto_entry table
    $sql = "INSERT INTO Auto_entry (date, vehicleNumber, busRoute, timeIn, numEmployees, reason)
            VALUES ('$date', '$vehicleNumber', '$busRoute', '$timeIn', '$numEmployees', '$reason')";

    if ($conn->query($sql) === TRUE) {
        header("Location: Auto.php"); // Redirect
        exit();
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>